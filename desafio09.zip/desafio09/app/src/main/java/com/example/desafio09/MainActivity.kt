package com.example.desafio09


import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.android.synthetic.main.activity_main.

class MainActivity : AppCompatActivity() {
    private val channelId = "MyChannelID"
    private val notificationId = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createNotificationChannel()

        scheduleButton.setOnClickListener {
            scheduleNotification()
        }
    }

    private fun createNotificationChannel() {
        val name = "My Channel"
        val descriptionText = "Channel Description"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel(channelId, name, importance).apply {
            description = descriptionText
        }
        val notificationManager: NotificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    private fun scheduleNotification() {
        val selectedDate = datePicker.date
        val selectedTime = timePicker.time

        val calendar = Calendar.getInstance()
        calendar.set(selectedDate.year, selectedDate.month, selectedDate.day, selectedTime.hour, selectedTime.minute)

        if (calendar.timeInMillis <= System.currentTimeMillis()) {
            // Verifique se a data e hora estão no futuro
            // Exiba uma mensagem de erro, se necessário
            return
        }

        val intent = Intent(this, NotificationReceiver::class.java)
        intent.putExtra("notification_id", notificationId)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Título da Notificação")
            .setContentText("Conteúdo da Notificação")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        val notificationManager = NotificationManagerCompat.from(this)
        notificationManager.notify(notificationId, builder.build())
    }
}
