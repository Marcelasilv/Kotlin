package com.example.desafio07

import android.location;
import android.locationListener;
import android.os.Bundle;

import androidx.annotation.NonNull;

class minhalocalizacaoListener implements locationListener{
    public static double latitude;
    public static double longitude;

    @Override
    public void  onLocationChanged(Location location){
        //location.getlatitude();
        //location.getlongitude();
        this.latitude = location.getlatitude();
        this.longitude= location.getLongitude();

    }
    @Override
    public void onProviderDisabled(@NonNull string provider){

    }
    @Override
    public void onProviderEnabled(@NonNull string provider){

    }
    @Override
    public void onStetusChanged(string provider, int status, Bundle extras){

    }
}